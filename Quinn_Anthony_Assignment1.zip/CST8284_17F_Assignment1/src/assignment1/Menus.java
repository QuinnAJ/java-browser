package assignment1;

import java.io.File;
import java.util.ArrayList;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.text.TextAlignment;
import javafx.scene.web.WebEngine;

public class Menus {
	private static MenuBar menuBar;
	
	private static Menu mnuFile;
	private static Menu mnuSettings;
	private static Menu mnuBookmarks;
	private static Menu mnuHelp;
	
	private static MenuItem mnuItmRefresh;
	private static MenuItem mnuItmExit;
	private static MenuItem mnuItmToggleAddressBar;
	private static MenuItem mnuItmChangeStartup;
	private static MenuItem mnuItmAddBookmark;
	private static MenuItem mnuItmAbout;
	
	private static ArrayList<String> bookmarks;
	private static boolean displayAddress;
	private static HBox hBox;
	
	public static MenuBar getMenuBar() {		
		return menuBar;		
	}
	public static MenuItem getMnuItmRefresh(WebEngine we) {
		mnuItmRefresh = new MenuItem("Refresh");
		mnuItmRefresh.setOnAction(e -> we.reload());
		return mnuItmRefresh;
	}
	public static MenuItem getMnuItmExit() {
		mnuItmExit = new MenuItem("Exit");
		mnuItmExit.setOnAction(e -> {
			Platform.exit();
		});
		return mnuItmExit;
	}
	public static ArrayList<String> getBookmarks() {
		return bookmarks;
	}
	public static MenuItem getMnuItmToggleAddressBar(WebEngine we) {
		displayAddress = false;
		hBox = new HBox();
		Label lbl = new Label("Enter Address");
		lbl.setTextAlignment(TextAlignment.CENTER);
		TextField txt = new TextField("address here");
		HBox.setHgrow(txt, Priority.ALWAYS);
		Button btn = new Button("Go");
		btn.setOnAction(e -> {we.load(txt.getText());});
		mnuItmToggleAddressBar = new MenuItem("Toggle Address Bar");
		mnuItmToggleAddressBar.setOnAction(e -> {
			displayAddress = !displayAddress;
			if(displayAddress) {
				hBox.getChildren().addAll(lbl,txt,btn);
			}else {
					hBox.getChildren().clear();
			}
		});
		return mnuItmToggleAddressBar;
	}
	public static MenuItem getMnuItmChangeStartup(WebEngine we) {
		mnuItmChangeStartup = new MenuItem("Change Startup");
		mnuItmChangeStartup.setOnAction(e -> {
			File defaultPage = new File("default.web");
			ArrayList<String> newDefault = new ArrayList<>();
			newDefault.add(we.getLocation());
			FileUtils.saveFileContents(defaultPage, newDefault);
		});
		return mnuItmChangeStartup;
	}
	public static MenuItem getMnuItmAddBookmark(WebEngine we) {
		mnuItmAddBookmark = new MenuItem("Add Bookmark");
		mnuItmAddBookmark.setOnAction(e -> {
			String bookmark = we.getLocation();
			MenuItem newBook = new MenuItem(bookmark);
			newBook.setOnAction(t -> we.load(bookmark));
			bookmarks.add(bookmark);
			mnuBookmarks.getItems().add(newBook);
		})
		;
		return mnuItmAddBookmark;
	}
	public static void getMnuItmBookmarks(WebEngine we) {
		File bookmarkf = new File("bookmarks.web");
		if (FileUtils.fileExists(bookmarkf)) {
			bookmarks = FileUtils.getFileContentsAsArrayList(bookmarkf);
			for(int i=0; i<bookmarks.size(); i++) {
				String bookmark = bookmarks.get(i);
				MenuItem newBook = new MenuItem(bookmark);
				newBook.setOnAction(e -> we.load(bookmark));
				mnuBookmarks.getItems().add(newBook);
			}
		}else {
			bookmarks = new ArrayList<String>();
		}
	}
	public static MenuItem getMnuItmAbout() {
		mnuItmAbout = new MenuItem("About");
		mnuItmAbout.setOnAction(e -> {
			Alert help = new Alert(AlertType.INFORMATION);
			help.setTitle("Help");
			help.setHeaderText(null);
			help.setContentText("Name: Anthony Quinn\nStudent Number: 040884399");
			help.showAndWait();
		});
		return mnuItmAbout;
	}
	public static HBox getAddressBar() {
		return hBox;
	}
	public static void createMenuBar(WebEngine we) {
		mnuFile = new Menu("File");
		mnuFile.getItems().addAll(getMnuItmRefresh(we), getMnuItmExit());
		
		mnuSettings = new Menu("Settings");
		mnuSettings.getItems().addAll(getMnuItmToggleAddressBar(we),getMnuItmChangeStartup(we));
		
		mnuBookmarks = new Menu("Bookmarks");
		mnuBookmarks.getItems().add(getMnuItmAddBookmark(we));
		getMnuItmBookmarks(we);
		
		
		mnuHelp = new Menu("Help");
		mnuHelp.getItems().add(getMnuItmAbout());
		
		menuBar = new MenuBar(mnuFile, mnuSettings, mnuBookmarks, mnuHelp);
	}
}

/*
 * General information on Menus gathered from:
 * Redko, Alla (2013). Using JavaFX UI Controls [Webpage]. Retrieved from
 * 	https://docs.oracle.com/javafx/2/ui_controls/menu_controls.htm
 * 
 * Code for using alerts adapted from:
 * Jakob, Marco (2014) JavaFX Dialogs (official) [Webpage]. Retrieved from
 * 	http://code.makery.ch/blog/javafx-dialogs-official/
 */
