package assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FileUtils {
	
   private String fileName;
   private String path;
   
   public static void saveFileContents(File f, ArrayList<String> ar) {
	   try {
		   PrintWriter output = new PrintWriter(f);
		   for(int i=0; i<ar.size(); i++) {
			   output.print(ar.get(i)+"\n");
		   }
		   output.close();
	   } catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }  
   }
   public static ArrayList<String> getFileContentsAsArrayList(File f){
	   ArrayList<String> arr = new ArrayList<>();
	   Scanner input;
	   try {
		   input = new Scanner(f);
		   while (input.hasNext()){
			   arr.add(input.next());
		   }
	   } catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }
	   return arr;
   }
   public static boolean fileExists(File f) {
	   return f.exists();
   }
   public static boolean fileExists(String s) {
	   return fileExists(new File(s));
   }
   public String getPath() {
	   return path;
   }
   public String getFileName() {
	   return fileName;
   }
   public void setPath(String s) {
	   path = s;
   }
   public void setFileName(String s) {
	   fileName = s;
   }
}
