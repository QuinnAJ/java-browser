/*
 * "Adapted from code supplied by Professor Dave Houtman, (2017)"
 */
package assignment1;

import java.io.File;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class MyJavaFXBrowser extends Application {

	@Override
	public void start(Stage primaryStage) {
				
	    WebPage currentPage = new WebPage();
		WebView webView = currentPage.getWebView();
		WebEngine webEngine = currentPage.createWebEngine(primaryStage);
		webEngine.load(defaultPage());
		
		Menus.createMenuBar(webEngine);
		VBox vBox = new VBox(Menus.getMenuBar());
		vBox.getChildren().add(Menus.getAddressBar());
		
		BorderPane root = new BorderPane();
		root.setCenter(webView);
		root.setTop(vBox);
		
		Scene scene = new Scene(root, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.show();	

	}
	
	@Override
	public void stop() {
		File bookmarkf = new File("bookmarks.web");
		FileUtils.saveFileContents(bookmarkf, Menus.getBookmarks());
	}
	
	public String defaultPage() {
		File defaultPage = new File("default.web");
		if (FileUtils.fileExists(defaultPage)) {
			return FileUtils.getFileContentsAsArrayList(defaultPage).get(0);
		}else {
			ArrayList<String> newDefault = new ArrayList<>();
			newDefault.add("http://www.google.ca");
			FileUtils.saveFileContents(defaultPage, newDefault);
			return "http://www.google.ca";
		}
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}

}
/*
 * Code for overwriting stop() adapted from:
 * Denvir, James (2017) Using JavaFX Application.stop() method over Shutdownhook [Webpage]. Retrieved from
 * 	https://stackoverflow.com/questions/42598097/using-javafx-application-stop-method-over-shutdownhook
 */
